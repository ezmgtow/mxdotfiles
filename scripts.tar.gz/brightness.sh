#!/bin/bash

input=$1
case $input in
	1) echo 777 | tee /sys/class/backlight/intel_backlight/brightness
;;
	10) echo 999 | tee /sys/class/backlight/intel_backlight/brightness
;;
	12) echo 1200 | tee /sys/class/backlight/intel_backlight/brightness
;;
	13) echo 1337 | tee /sys/class/backlight/intel_backlight/brightness
;;
	17) echo 1773 | tee /sys/class/backlight/intel_backlight/brightness
;;
	19) echo 1900 | tee /sys/class/backlight/intel_backlight/brightness
;;
	21) echo 2133 | tee /sys/class/backlight/intel_backlight/brightness
;;
	23) echo 2300 | tee /sys/class/backlight/intel_backlight/brightness
;;
	24) echo 2473 | tee /sys/class/backlight/intel_backlight/brightness
;;
	27) echo 2773 | tee /sys/class/backlight/intel_backlight/brightness
;;
	3) echo 3000 | tee /sys/class/backlight/intel_backlight/brightness
;;
	31) echo 3133 | tee /sys/class/backlight/intel_backlight/brightness
;;
	33) echo 3300 | tee /sys/class/backlight/intel_backlight/brightness
;;
	34) echo 3473 | tee /sys/class/backlight/intel_backlight/brightness
;;
	37) echo 3773 | tee /sys/class/backlight/intel_backlight/brightness
;;
	4) echo 4000 | tee /sys/class/backlight/intel_backlight/brightness
;;
	43) echo 4300 | tee /sys/class/backlight/intel_backlight/brightness
;;
	44) echo 4473 | tee /sys/class/backlight/intel_backlight/brightness
;;
	47) echo 4773 | tee /sys/class/backlight/intel_backlight/brightness
;;
	*) cat /sys/class/backlight/intel_backlight/brightness
;;
esac

#echo 4000 | sudo tee /sys/class/backlight/intel_backlight/brightness



