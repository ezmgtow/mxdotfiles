#!/bin/bash

input=$1
case $input in
	1) echo 1 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	3) echo 3 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	4) echo 4 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	7) echo 7 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	9) echo 9 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	10) echo 10 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	12) echo 12 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	13) echo 13 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	17) echo 17 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	19) echo 19 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	21) echo 21 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	23) echo 23 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	24) echo 24 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	27) echo 27 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	30) echo 30 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	31) echo 31 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	33) echo 33 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	34) echo 34 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	37) echo 37 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	40) echo 40 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	43) echo 43 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	44) echo 44 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	47) echo 47 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	49) echo 49 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	60) echo 60 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	66) echo 66 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	67) echo 67 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	69) echo 69 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	70) echo 70 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	73) echo 73 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	74) echo 74 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	77) echo 77 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	80) echo 80 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	88) echo 88 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	99) echo 99 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	100) echo 100 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	112) echo 112 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	120) echo 120 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	130) echo 130 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	137) echo 137 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	170) echo 170 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	173) echo 173 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	177) echo 177 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	187) echo 187 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	190) echo 190 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	197) echo 197 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	199) echo 199 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	230) echo 230 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	240) echo 240 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	247) echo 247 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness
;;
	*) cat /sys/class/backlight/amdgpu_bl0/brightness
;;
esac

#echo 4000 | sudo tee /sys/class/backlight/amdgpu_bl0/brightness



