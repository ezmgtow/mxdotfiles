#!/bin/bash

# Perform Small Backups  #
cp -ruv $HOME/Desktop $HOME/.scripts $HOME/.config $HOME/.bash_aliases $HOME/.fasd $HOME/.dmrc $HOME/.viminfo $HOME/.profile $HOME/.vimrc /mnt/mystuff/newmgtowbackupsmall

