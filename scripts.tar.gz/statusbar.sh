#!/bin/bash

while true ; do xsetroot -name "`sed -n '8 s_.\{11\}\([0-9]\)\([0-9]\).*$_\ \ \1\.\2  _p' /proc/cpuinfo``mpstat --dec=0 1 1 | tail -c 4 | awk '{print (100-$1"%  ")}'``sed s/000$/\'C\ \ / /sys/class/thermal/thermal_zone0/temp``free -h | awk '/:/ {print $3}' | tr '\n' ' '``echo " "``date +%R` "; sleep 3 ; done &
