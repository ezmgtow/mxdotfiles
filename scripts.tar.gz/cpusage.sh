#!/bin/bash

mpstat --dec=0 1 1 | tail -1 | awk '{print 100-$12"%  "}'
#usage=$(mpstat --dec=0 1 1 | tail -1 | awk '{print 100-$12"% "}')
#echo $usage"  "
#usage=$(mpstat | sed '1,3d;s/.* //')
#output="$(bc <<< "100 - $usage")"
#bc <<< "100 - $usage" | sed 's/\.../% /'
#echo $output
