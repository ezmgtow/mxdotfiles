
#!/bin/bash

while true ; do 
	sed -n '8 s_.\{11\}\([0-9]\)\([0-9]\).*$_\ \ \1\.\2  _p' /proc/cpuinfo | tr '\n' ' '
	sed s/000$/\'C\ \ / /sys/class/thermal/thermal_zone0/temp | tr '\n' ' '
	free -h | awk '/:/ {print $3}' | tr '\n' ' '; 

	#while true ; do `sed -n '8 s_.\{11\}\([0-9]\)\([0-9]\).*$_\ \ \1\.\2  _p' /proc/cpuinfo``sed s/000$/\'C\ \ / /sys/class/thermal/thermal_zone0/temp``free -h | awk '/:/ {print $3}' `; 

	#while true ; do xsetroot -name "`sed -n '8 s_.\{11\}\([0-9]\)\([0-9]\).*$_\ \ \1\.\2  _p' /proc/cpuinfo``sed s/000$/\'C\ \ / /sys/class/thermal/thermal_zone0/temp``free -h | awk '/:/ {print $3}' ` "; 


read cpu a b c previdle rest < /proc/stat
	prevtotal=$((a+b+c+previdle))
	sleep 0.5
	read cpu a b c idle rest < /proc/stat
	total=$((a+b+c+idle))
	cpu=$((100*( (total-prevtotal) - (idle-previdle) ) / (total-prevtotal) ))
	echo "$cpu%"

	sleep 2 ; done &
